"""
Migration: adds password column to doctors + default schedule seed.
Run once: python migrate_db.py
"""
import sqlite3, os, hashlib

DB_PATH = os.path.join(os.path.dirname(__file__), 'medimanage.db')

def h(p):
    return hashlib.sha256(p.encode()).hexdigest()

conn   = sqlite3.connect(DB_PATH)
cursor = conn.cursor()

# 1. Add password column to doctors
try:
    cursor.execute("ALTER TABLE doctors ADD COLUMN password TEXT")
    print("[+] Added password column to doctors")
except sqlite3.OperationalError:
    print("[=] password column already exists")

# 2. Set default password for doctors that don't have one
cursor.execute("SELECT id, email FROM doctors WHERE password IS NULL OR password = ''")
for doc_id, email in cursor.fetchall():
    cursor.execute("UPDATE doctors SET password=? WHERE id=?", (h("Doctor@1234"), doc_id))
    print(f"    Set default password for doctor id={doc_id}  ({email})")

# 3. Seed sample schedules if table is empty
count = cursor.execute("SELECT COUNT(*) FROM doctor_schedules").fetchone()[0]
if count == 0:
    doctors = cursor.execute("SELECT id FROM doctors LIMIT 6").fetchall()
    days = ['Monday','Tuesday','Wednesday','Thursday','Friday']
    for (doc_id,) in doctors:
        for day in days:
            cursor.execute(
                "INSERT INTO doctor_schedules (doctor_id, day_of_week, start_time, end_time) VALUES (?,?,?,?)",
                (doc_id, day, '09:00', '13:00')
            )
            cursor.execute(
                "INSERT INTO doctor_schedules (doctor_id, day_of_week, start_time, end_time) VALUES (?,?,?,?)",
                (doc_id, day, '14:00', '17:00')
            )
    print("[+] Seeded default schedules (Mon-Fri, 09:00-13:00 & 14:00-17:00)")

conn.commit()
conn.close()
print()
print("[OK] Migration complete!")
print("     Default doctor login password : Doctor@1234")
