import sqlite3
import hashlib
import os

DB_PATH = os.path.join(os.path.dirname(__file__), "medimanage.db")

def hash_password(password):
    return hashlib.sha256(password.encode()).hexdigest()

def create_database():
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()

    # ─────────────────────────────────────────
    # TABLE: admins
    # ─────────────────────────────────────────
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS admins (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            name        TEXT    NOT NULL,
            email       TEXT    NOT NULL UNIQUE,
            password    TEXT    NOT NULL,
            created_at  TEXT    DEFAULT (datetime('now'))
        )
    """)

    # ─────────────────────────────────────────
    # TABLE: patients
    # ─────────────────────────────────────────
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS patients (
            id           INTEGER PRIMARY KEY AUTOINCREMENT,
            name         TEXT    NOT NULL,
            email        TEXT    NOT NULL UNIQUE,
            password     TEXT    NOT NULL,
            phone        TEXT,
            dob          TEXT,
            gender       TEXT    CHECK(gender IN ('Male', 'Female', 'Other')),
            blood_group  TEXT,
            address      TEXT,
            created_at   TEXT    DEFAULT (datetime('now'))
        )
    """)

    # ─────────────────────────────────────────
    # TABLE: specialties
    # ─────────────────────────────────────────
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS specialties (
            id   INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT    NOT NULL UNIQUE
        )
    """)

    # ─────────────────────────────────────────
    # TABLE: doctors
    # ─────────────────────────────────────────
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS doctors (
            id             INTEGER PRIMARY KEY AUTOINCREMENT,
            name           TEXT    NOT NULL,
            email          TEXT    NOT NULL UNIQUE,
            phone          TEXT,
            specialty_id   INTEGER REFERENCES specialties(id),
            experience     INTEGER DEFAULT 0,
            qualification  TEXT,
            status         TEXT    DEFAULT 'Available'
                           CHECK(status IN ('Available', 'On Leave', 'In Surgery')),
            bio            TEXT,
            image_url      TEXT,
            created_at     TEXT    DEFAULT (datetime('now'))
        )
    """)

    # ─────────────────────────────────────────
    # TABLE: doctor_schedules
    # ─────────────────────────────────────────
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS doctor_schedules (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            doctor_id   INTEGER NOT NULL REFERENCES doctors(id) ON DELETE CASCADE,
            day_of_week TEXT    NOT NULL
                        CHECK(day_of_week IN ('Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday')),
            start_time  TEXT    NOT NULL,
            end_time    TEXT    NOT NULL
        )
    """)

    # ─────────────────────────────────────────
    # TABLE: appointments
    # ─────────────────────────────────────────
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS appointments (
            id             INTEGER PRIMARY KEY AUTOINCREMENT,
            patient_id     INTEGER NOT NULL REFERENCES patients(id) ON DELETE CASCADE,
            doctor_id      INTEGER NOT NULL REFERENCES doctors(id) ON DELETE CASCADE,
            appt_date      TEXT    NOT NULL,
            appt_time      TEXT    NOT NULL,
            reason         TEXT,
            status         TEXT    DEFAULT 'Pending'
                           CHECK(status IN ('Pending', 'Confirmed', 'Completed', 'Cancelled')),
            notes          TEXT,
            created_at     TEXT    DEFAULT (datetime('now'))
        )
    """)

    # ─────────────────────────────────────────
    # SEED: Specialties
    # ─────────────────────────────────────────
    specialties = [
        "Cardiology", "Neurology", "Pediatrics",
        "Orthopedics", "General Surgery", "Dermatology",
        "Oncology", "Psychiatry"
    ]
    for s in specialties:
        cursor.execute("INSERT OR IGNORE INTO specialties (name) VALUES (?)", (s,))

    # ─────────────────────────────────────────
    # SEED: Admin user
    # ─────────────────────────────────────────
    cursor.execute("""
        INSERT OR IGNORE INTO admins (name, email, password)
        VALUES (?, ?, ?)
    """, ("Super Admin", "admin@hospital.com", hash_password("Admin@1234")))

    # ─────────────────────────────────────────
    # SEED: Sample doctors
    # ─────────────────────────────────────────
    sample_doctors = [
        ("Dr. Sarah Jenkins",   "sarah.jenkins@hospital.com",   "+91-9000000001", 1, 12, "MD, FACC",          "Available",  "Expert in interventional cardiology."),
        ("Dr. Michael Chen",    "michael.chen@hospital.com",    "+91-9000000002", 2,  8, "MD, DM Neurology",  "In Surgery", "Specializes in epilepsy and stroke care."),
        ("Dr. Emily Rodriguez", "emily.rodriguez@hospital.com", "+91-9000000003", 3,  5, "MD, DCH",           "Available",  "Dedicated paediatric physician."),
        ("Dr. James Wilson",    "james.wilson@hospital.com",    "+91-9000000004", 4, 15, "MS Orthopaedics",   "On Leave",   "Joint replacement & sports injuries."),
        ("Dr. Olivia Martinez", "olivia.martinez@hospital.com", "+91-9000000005", 5, 10, "MS General Surgery","Available",  "Laparoscopic & oncological surgery."),
        ("Dr. David Kim",       "david.kim@hospital.com",       "+91-9000000006", 1,  7, "MD, DNB Cardiology","Available",  "Cardiac imaging & heart failure."),
    ]
    for doc in sample_doctors:
        cursor.execute("""
            INSERT OR IGNORE INTO doctors
                (name, email, phone, specialty_id, experience, qualification, status, bio)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """, doc)

    # ─────────────────────────────────────────
    # SEED: Sample patient
    # ─────────────────────────────────────────
    cursor.execute("""
        INSERT OR IGNORE INTO patients (name, email, password, phone, gender, blood_group)
        VALUES (?, ?, ?, ?, ?, ?)
    """, ("John Patient", "john@example.com", hash_password("Patient@1234"), "+91-9999999999", "Male", "O+"))

    conn.commit()
    conn.close()
    print(f"[OK] Database created successfully at: {DB_PATH}")
    print()
    print("  Tables created : admins, patients, specialties, doctors, doctor_schedules, appointments")
    print()
    print("  Seed data loaded:")
    print("    - 8 specialties")
    print("    - 1 admin   :  admin@hospital.com  /  Admin@1234")
    print("    - 6 doctors")
    print("    - 1 patient :  john@example.com    /  Patient@1234")

if __name__ == "__main__":
    create_database()
