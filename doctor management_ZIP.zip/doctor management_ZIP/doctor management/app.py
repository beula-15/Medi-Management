from flask import Flask, render_template, request, redirect, url_for, session, flash, jsonify
import sqlite3
import hashlib
import os
import uuid
import json
import threading
import requests
from datetime import datetime, timedelta
from functools import wraps
from werkzeug.utils import secure_filename
from twilio.rest import Client

app = Flask(__name__)
app.secret_key = 'medimanage-super-secret-key-2026'

TWILIO_ACCOUNT_SID = 'AC6902d2f227b8877ccd6db562d5168431'
TWILIO_AUTH_TOKEN = '43ef15fffa4e7cd2c664502b7ad713ef'
TWILIO_PHONE_NUMBER = '+16205571922'

def send_sms_async(to_phone, message):
    if not TWILIO_ACCOUNT_SID or TWILIO_ACCOUNT_SID == 'YOUR_TWILIO_ACCOUNT_SID':
        print(f"\n[SIMULATED SMS to {to_phone}]: {message}\n")
        return
        
    try:
        # Twilio requires E.164 format (e.g., +919876543210). Fix local numbers if needed.
        formatted_phone = to_phone
        if not formatted_phone.startswith('+'):
            # Strip spaces, dashes, etc
            clean_phone = ''.join(filter(str.isdigit, formatted_phone))
            if len(clean_phone) == 10:
                formatted_phone = '+91' + clean_phone
            
        client = Client(TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN)
        response = client.messages.create(
            body=message,
            from_=TWILIO_PHONE_NUMBER,
            to=formatted_phone
        )
        print(f"Twilio Response: SMS sent successfully, SID: {response.sid}")
    except Exception as e:
        print(f"Failed to send SMS via Twilio to {to_phone}: {e}")

def send_sms(to_phone, message):
    threading.Thread(target=send_sms_async, args=(to_phone, message)).start()

DB_PATH      = os.path.join(os.path.dirname(__file__), 'medimanage.db')
UPLOAD_FOLDER = os.path.join(os.path.dirname(__file__), 'static', 'uploads', 'doctors')
RECORDS_FOLDER = os.path.join(os.path.dirname(__file__), 'static', 'uploads', 'records')
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif', 'webp', 'pdf'}
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
os.makedirs(RECORDS_FOLDER, exist_ok=True)

# ─────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────
def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def hash_password(p):
    return hashlib.sha256(p.encode()).hexdigest()

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def save_doctor_photo(file):
    if not file or file.filename == '':
        return None
    if not allowed_file(file.filename):
        return None
    ext  = file.filename.rsplit('.', 1)[1].lower()
    name = f"{uuid.uuid4().hex}.{ext}"
    file.save(os.path.join(UPLOAD_FOLDER, name))
    return name

def patient_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if 'patient_id' not in session:
            flash('Please log in to continue.', 'error')
            return redirect(url_for('patient_login'))
        return f(*args, **kwargs)
    return decorated

def admin_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if 'admin_id' not in session:
            flash('Admin access required.', 'error')
            return redirect(url_for('admin_login'))
        return f(*args, **kwargs)
    return decorated

def doctor_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if 'doctor_id' not in session:
            flash('Please log in as a doctor.', 'error')
            return redirect(url_for('doctor_login'))
        return f(*args, **kwargs)
    return decorated

# ─────────────────────────────────────────
# Portal Selection
# ─────────────────────────────────────────
@app.route('/')
def index():
    return render_template('index.html')

# ═══════════════════════════════════════════
# PATIENT ROUTES
# ═══════════════════════════════════════════
@app.route('/patient/register', methods=['GET', 'POST'])
def patient_register():
    if request.method == 'POST':
        name  = request.form.get('name','').strip()
        email = request.form.get('email','').strip()
        pwd   = request.form.get('password','')
        if not all([name, email, pwd]):
            flash('Name, email, and password are required.', 'error')
            return render_template('patient_register.html')
        try:
            conn = get_db()
            conn.execute(
                'INSERT INTO patients (name, email, password, phone, dob, gender, blood_group) VALUES (?,?,?,?,?,?,?)',
                (name, email, hash_password(pwd),
                 request.form.get('phone',''),
                 request.form.get('dob',''),
                 request.form.get('gender',''),
                 request.form.get('blood_group',''))
            )
            conn.commit(); conn.close()
            flash('Registration successful! Please log in.', 'success')
            return redirect(url_for('patient_login'))
        except sqlite3.IntegrityError:
            flash('This email is already registered.', 'error')
    return render_template('patient_register.html')

@app.route('/patient/login', methods=['GET', 'POST'])
def patient_login():
    if request.method == 'POST':
        email = request.form.get('email','').strip()
        pwd   = request.form.get('password','')
        conn  = get_db()
        p = conn.execute('SELECT * FROM patients WHERE email=? AND password=?',
                         (email, hash_password(pwd))).fetchone()
        conn.close()
        if p:
            session['patient_id']   = p['id']
            session['patient_name'] = p['name']
            return redirect(url_for('patient_dashboard'))
        flash('Invalid email or password.', 'error')
    return render_template('patient_login.html')

@app.route('/patient/dashboard')
@patient_required
def patient_dashboard():
    specialty_filter = request.args.get('specialty', 'all')
    search           = request.args.get('search', '').strip()
    conn   = get_db()
    query  = 'SELECT d.*, s.name AS specialty_name FROM doctors d JOIN specialties s ON d.specialty_id=s.id WHERE 1=1'
    params = []
    if specialty_filter != 'all':
        query += ' AND s.name=?'; params.append(specialty_filter)
    if search:
        query += ' AND (d.name LIKE ? OR s.name LIKE ?)'; params += [f'%{search}%', f'%{search}%']
    doctors     = conn.execute(query, params).fetchall()
    specialties = conn.execute('SELECT * FROM specialties ORDER BY name').fetchall()
    conn.close()
    return render_template('patient_dashboard.html',
                           doctors=doctors, specialties=specialties,
                           current_specialty=specialty_filter, search=search)

@app.route('/patient/book/<int:doctor_id>', methods=['GET', 'POST'])
@patient_required
def book_appointment(doctor_id):
    conn   = get_db()
    doctor = conn.execute(
        'SELECT d.*, s.name AS specialty_name FROM doctors d JOIN specialties s ON d.specialty_id=s.id WHERE d.id=?',
        (doctor_id,)
    ).fetchone()
    if not doctor:
        conn.close(); flash('Doctor not found.', 'error')
        return redirect(url_for('patient_dashboard'))
    if request.method == 'POST':
        appt_date = request.form.get('appt_date')
        appt_time = request.form.get('appt_time')
        reason    = request.form.get('reason','').strip()
        fee       = doctor['consultation_fee'] or 500
        conn.execute(
            'INSERT INTO appointments (patient_id, doctor_id, appt_date, appt_time, reason, fee, payment_status) VALUES (?,?,?,?,?,?,?)',
            (session['patient_id'], doctor_id, appt_date, appt_time, reason, fee, 'Unpaid')
        )
        conn.commit()
        
        patient = conn.execute('SELECT phone, name FROM patients WHERE id=?', (session['patient_id'],)).fetchone()
        if patient and patient['phone']:
            msg = f"Dear {patient['name']}, your appointment with Dr. {doctor['name']} is booked for {appt_date} at {appt_time}. Please pay the fee to confirm."
            send_sms(patient['phone'], msg)
            
        conn.close()
        flash('Appointment booked successfully! Please pay the consultation fee.', 'success')
        return redirect(url_for('my_appointments'))
    conn.close()
    return render_template('book_appointment.html', doctor=doctor)

@app.route('/patient/appointments')
@patient_required
def my_appointments():
    conn = get_db()
    appts = conn.execute(
        '''SELECT a.*, d.name AS doctor_name, s.name AS specialty_name
           FROM appointments a JOIN doctors d ON a.doctor_id=d.id JOIN specialties s ON d.specialty_id=s.id
           WHERE a.patient_id=? ORDER BY a.appt_date DESC, a.appt_time DESC''',
        (session['patient_id'],)
    ).fetchall()
    conn.close()
    return render_template('my_appointments.html', appointments=appts)

@app.route('/patient/appointments/cancel/<int:appt_id>', methods=['POST'])
@patient_required
def cancel_appointment(appt_id):
    conn = get_db()
    
    appt = conn.execute('SELECT a.appt_date, a.appt_time, d.name AS doctor_name FROM appointments a JOIN doctors d ON a.doctor_id = d.id WHERE a.id=? AND a.patient_id=?', (appt_id, session['patient_id'])).fetchone()
    
    conn.execute("UPDATE appointments SET status='Cancelled' WHERE id=? AND patient_id=?",
                 (appt_id, session['patient_id']))
    conn.commit()
    
    patient = conn.execute('SELECT phone, name FROM patients WHERE id=?', (session['patient_id'],)).fetchone()
    if patient and patient['phone'] and appt:
        msg = f"Dear {patient['name']}, your appointment with Dr. {appt['doctor_name']} on {appt['appt_date']} at {appt['appt_time']} has been cancelled."
        send_sms(patient['phone'], msg)
        
    conn.close()
    flash('Appointment cancelled.', 'success')
    return redirect(url_for('my_appointments'))

@app.route('/patient/profile', methods=['GET', 'POST'])
@patient_required
def patient_profile():
    conn = get_db()
    if request.method == 'POST':
        conn.execute(
            'UPDATE patients SET name=?, phone=?, dob=?, gender=?, blood_group=?, address=? WHERE id=?',
            (request.form.get('name'), request.form.get('phone'), request.form.get('dob'),
             request.form.get('gender'), request.form.get('blood_group'), request.form.get('address'),
             session['patient_id'])
        )
        conn.commit()
        session['patient_name'] = request.form.get('name')
        flash('Profile updated successfully!', 'success')
        return redirect(url_for('patient_profile'))

    patient = conn.execute('SELECT * FROM patients WHERE id=?', (session['patient_id'],)).fetchone()
    records = conn.execute('SELECT * FROM patient_records WHERE patient_id=? ORDER BY upload_date DESC',
                           (session['patient_id'],)).fetchall()
    conn.close()
    return render_template('patient_profile.html', patient=patient, records=records)

@app.route('/patient/records/upload', methods=['POST'])
@patient_required
def upload_record():
    file = request.files.get('file')
    label = request.form.get('label','Medical Record')
    if file and file.filename != '':
        ext = file.filename.rsplit('.', 1)[1].lower() if '.' in file.filename else 'dat'
        name = f"rec_{uuid.uuid4().hex}.{ext}"
        path = os.path.join(os.path.dirname(__file__), 'static', 'uploads', 'records')
        os.makedirs(path, exist_ok=True)
        file.save(os.path.join(path, name))
        conn = get_db()
        conn.execute('INSERT INTO patient_records (patient_id, file_name, label) VALUES (?,?,?)',
                     (session['patient_id'], name, label))
        conn.commit(); conn.close()
        flash('Medical record uploaded successfully!', 'success')
    return redirect(url_for('patient_profile'))

@app.route('/patient/pay/<int:appt_id>', methods=['GET', 'POST'])
@patient_required
def patient_pay(appt_id):
    conn = get_db()
    appt = conn.execute(
        'SELECT a.*, d.name AS doctor_name FROM appointments a JOIN doctors d ON a.doctor_id=d.id WHERE a.id=? AND a.patient_id=?',
        (appt_id, session['patient_id'])
    ).fetchone()
    if not appt:
        conn.close()
        return redirect(url_for('my_appointments'))

    # Guard: already paid
    if appt['payment_status'] == 'Paid':
        conn.close()
        flash('This appointment has already been paid.', 'info')
        return redirect(url_for('my_appointments'))

    if request.method == 'POST':
        payment_method = request.form.get('payment_method', 'card')
        txn_id = 'TXN' + uuid.uuid4().hex[:10].upper()
        # Try to store payment_method; column may not exist yet — fall back gracefully
        try:
            conn.execute(
                "UPDATE appointments SET payment_status='Paid', status='Confirmed', payment_method=?, txn_id=? WHERE id=?",
                (payment_method, txn_id, appt_id)
            )
        except Exception:
            conn.execute(
                "UPDATE appointments SET payment_status='Paid', status='Confirmed' WHERE id=?",
                (appt_id,)
            )
        conn.commit()
        
        patient = conn.execute('SELECT phone, name FROM patients WHERE id=?', (session['patient_id'],)).fetchone()
        if patient and patient['phone']:
            msg = f"Dear {patient['name']}, payment of Rs.{appt['fee']} successful (TXN: {txn_id}). Your appointment with Dr. {appt['doctor_name']} is CONFIRMED."
            send_sms(patient['phone'], msg)
            
        conn.close()
        flash(f'Payment of ₹{appt["fee"]} successful via {payment_method.title()}! Your appointment is now confirmed. TXN ID: {txn_id}', 'success')
        return redirect(url_for('my_appointments'))

    conn.close()
    return render_template('patient_pay.html', appointment=appt)

@app.route('/forgot-password', methods=['GET', 'POST'])
def forgot_password():
    if request.method == 'POST':
        email = request.form.get('email')
        # Simulate sending reset link
        flash(f'If an account exists for {email}, a reset link has been sent.', 'info')
        return redirect(url_for('index'))
    return render_template('forgot_password.html')

# ═══════════════════════════════════════════
# DOCTOR ROUTES
# ═══════════════════════════════════════════
@app.route('/doctor/login', methods=['GET', 'POST'])
def doctor_login():
    if request.method == 'POST':
        email = request.form.get('email','').strip()
        pwd   = request.form.get('password','')
        conn  = get_db()
        doc   = conn.execute(
            'SELECT d.*, s.name AS specialty_name FROM doctors d JOIN specialties s ON d.specialty_id=s.id WHERE d.email=? AND d.password=?',
            (email, hash_password(pwd))
        ).fetchone()
        conn.close()
        if doc:
            session['doctor_id']   = doc['id']
            session['doctor_name'] = doc['name']
            return redirect(url_for('doctor_dashboard'))
        flash('Invalid email or password.', 'error')
    return render_template('doctor_login.html')

@app.route('/doctor/dashboard')
@doctor_required
def doctor_dashboard():
    conn   = get_db()
    doctor = conn.execute(
        'SELECT d.*, s.name AS specialty_name FROM doctors d JOIN specialties s ON d.specialty_id=s.id WHERE d.id=?',
        (session['doctor_id'],)
    ).fetchone()
    appointments = conn.execute(
        '''SELECT a.*, p.name AS patient_name, p.phone AS patient_phone, p.blood_group
           FROM appointments a JOIN patients p ON a.patient_id=p.id
           WHERE a.doctor_id=? ORDER BY a.appt_date ASC, a.appt_time ASC''',
        (session['doctor_id'],)
    ).fetchall()
    schedules = conn.execute(
        'SELECT * FROM doctor_schedules WHERE doctor_id=? ORDER BY id',
        (session['doctor_id'],)
    ).fetchall()
    stats = {
        'total':     conn.execute('SELECT COUNT(*) FROM appointments WHERE doctor_id=?', (session['doctor_id'],)).fetchone()[0],
        'pending':   conn.execute("SELECT COUNT(*) FROM appointments WHERE doctor_id=? AND status='Pending'",   (session['doctor_id'],)).fetchone()[0],
        'confirmed': conn.execute("SELECT COUNT(*) FROM appointments WHERE doctor_id=? AND status='Confirmed'", (session['doctor_id'],)).fetchone()[0],
        'completed': conn.execute("SELECT COUNT(*) FROM appointments WHERE doctor_id=? AND status='Completed'", (session['doctor_id'],)).fetchone()[0],
    }
    conn.close()
    return render_template('doctor_dashboard.html',
                           doctor=doctor, appointments=appointments,
                           schedules=schedules, stats=stats)

@app.route('/doctor/appointment/update/<int:appt_id>', methods=['POST'])
@doctor_required
def doctor_update_appt(appt_id):
    status = request.form.get('status')
    conn   = get_db()
    conn.execute('UPDATE appointments SET status=? WHERE id=? AND doctor_id=?',
                 (status, appt_id, session['doctor_id']))
    conn.commit(); conn.close()
    flash(f'Appointment updated to {status}.', 'success')
    return redirect(url_for('doctor_dashboard'))

@app.route('/doctor/appointment/prescription/<int:appt_id>', methods=['POST'])
@doctor_required
def doctor_prescription(appt_id):
    notes = request.form.get('notes','').strip()
    conn  = get_db()
    conn.execute('UPDATE appointments SET prescription_notes=? WHERE id=? AND doctor_id=?',
                 (notes, appt_id, session['doctor_id']))
    conn.commit(); conn.close()
    flash('Prescription/Notes updated.', 'success')
    return redirect(url_for('doctor_dashboard'))

# ═══════════════════════════════════════════
# ADMIN ROUTES
# ═══════════════════════════════════════════
@app.route('/admin/login', methods=['GET', 'POST'])
def admin_login():
    if request.method == 'POST':
        email = request.form.get('email','').strip()
        pwd   = request.form.get('password','')
        conn  = get_db()
        admin = conn.execute('SELECT * FROM admins WHERE email=? AND password=?',
                             (email, hash_password(pwd))).fetchone()
        conn.close()
        if admin:
            session['admin_id']   = admin['id']
            session['admin_name'] = admin['name']
            return redirect(url_for('admin_dashboard'))
        flash('Invalid admin credentials.', 'error')
    return render_template('admin_login.html')

@app.route('/admin/dashboard')
@admin_required
def admin_dashboard():
    conn = get_db()

    # Doctors + Appointments
    doctors = conn.execute(
        'SELECT d.*, s.name AS specialty_name FROM doctors d JOIN specialties s ON d.specialty_id=s.id ORDER BY d.name'
    ).fetchall()
    appointments = conn.execute(
        '''SELECT a.*, p.name AS patient_name, d.name AS doctor_name
           FROM appointments a JOIN patients p ON a.patient_id=p.id JOIN doctors d ON a.doctor_id=d.id
           ORDER BY a.appt_date DESC'''
    ).fetchall()
    specialties = conn.execute('SELECT * FROM specialties ORDER BY name').fetchall()

    # Stats
    stats = {
        'total_doctors':        conn.execute('SELECT COUNT(*) FROM doctors').fetchone()[0],
        'total_patients':       conn.execute('SELECT COUNT(*) FROM patients').fetchone()[0],
        'total_appointments':   conn.execute('SELECT COUNT(*) FROM appointments').fetchone()[0],
        'pending_appointments': conn.execute("SELECT COUNT(*) FROM appointments WHERE status='Pending'").fetchone()[0],
    }

    # ── Analytics ──
    # Monthly appointments (last 6 months)
    monthly_raw = conn.execute(
        """SELECT strftime('%Y-%m', appt_date) AS month, COUNT(*) AS cnt
           FROM appointments
           WHERE appt_date >= date('now','-5 months','start of month')
           GROUP BY month ORDER BY month"""
    ).fetchall()

    # Build last-6-month labels (fill missing with 0)
    monthly_map = {r['month']: r['cnt'] for r in monthly_raw}
    monthly_labels, monthly_data = [], []
    for i in range(5, -1, -1):
        dt  = datetime.now().replace(day=1) - timedelta(days=i*30)
        key = dt.strftime('%Y-%m')
        monthly_labels.append(dt.strftime('%b %Y'))
        monthly_data.append(monthly_map.get(key, 0))

    # Status breakdown
    status_rows = conn.execute(
        "SELECT status, COUNT(*) AS cnt FROM appointments GROUP BY status"
    ).fetchall()
    status_labels = [r['status'] for r in status_rows]
    status_data   = [r['cnt']    for r in status_rows]

    # Top 5 doctors by appointment count
    top_docs_rows = conn.execute(
        """SELECT d.name, COUNT(a.id) AS cnt
           FROM doctors d LEFT JOIN appointments a ON d.id=a.doctor_id
           GROUP BY d.id ORDER BY cnt DESC LIMIT 5"""
    ).fetchall()
    top_doc_labels = [r['name'] for r in top_docs_rows]
    top_doc_data   = [r['cnt']  for r in top_docs_rows]

    # Doctor availability distribution
    availability_rows = conn.execute(
        "SELECT status, COUNT(*) AS cnt FROM doctors GROUP BY status"
    ).fetchall()
    avail_labels = [r['status'] for r in availability_rows]
    avail_data   = [r['cnt']    for r in availability_rows]

    # Admin Logs
    logs = conn.execute(
        'SELECT l.*, a.name AS admin_name FROM admin_logs l JOIN admins a ON l.admin_id=a.id ORDER BY l.timestamp DESC LIMIT 10'
    ).fetchall()

    conn.close()
    return render_template('admin_dashboard.html',
                           doctors=doctors, appointments=appointments,
                           specialties=specialties, stats=stats, logs=logs,
                           monthly_labels=json.dumps(monthly_labels),
                           monthly_data=json.dumps(monthly_data),
                           status_labels=json.dumps(status_labels),
                           status_data=json.dumps(status_data),
                           top_doc_labels=json.dumps(top_doc_labels),
                           top_doc_data=json.dumps(top_doc_data),
                           avail_labels=json.dumps(avail_labels),
                           avail_data=json.dumps(avail_data))

# Admin: Add Doctor
@app.route('/admin/doctors/add', methods=['POST'])
@admin_required
def add_doctor():
    photo_filename = save_doctor_photo(request.files.get('photo'))
    pwd = hash_password(request.form.get('password') or 'Doctor@1234')
    try:
        conn = get_db()
        conn.execute(
            '''INSERT INTO doctors (name, email, phone, specialty_id, experience, qualification, status, bio, image_url, password, consultation_fee)
               VALUES (?,?,?,?,?,?,?,?,?,?,?)''',
            (request.form.get('name'), request.form.get('email'), request.form.get('phone'),
             request.form.get('specialty_id'), request.form.get('experience', 0),
             request.form.get('qualification'), request.form.get('status','Available'),
             request.form.get('bio'), photo_filename, pwd, request.form.get('consultation_fee', 500))
        )
        conn.execute('INSERT INTO admin_logs (admin_id, action) VALUES (?,?)',
                     (session['admin_id'], f"Registered new doctor: {request.form.get('name')}"))
        conn.commit(); conn.close()
        flash('Doctor registered successfully!', 'success')
    except sqlite3.IntegrityError:
        flash('A doctor with this email already exists.', 'error')
    return redirect(url_for('admin_dashboard'))

# Admin: Edit Doctor
@app.route('/admin/doctors/edit/<int:doctor_id>', methods=['POST'])
@admin_required
def edit_doctor(doctor_id):
    conn      = get_db()
    new_photo = save_doctor_photo(request.files.get('photo'))
    new_pwd   = request.form.get('password','').strip()
    if new_photo:
        old = conn.execute('SELECT image_url FROM doctors WHERE id=?', (doctor_id,)).fetchone()
        if old and old['image_url']:
            p = os.path.join(UPLOAD_FOLDER, old['image_url'])
            if os.path.exists(p): os.remove(p)
        conn.execute(
            'UPDATE doctors SET name=?,email=?,phone=?,specialty_id=?,experience=?,qualification=?,status=?,bio=?,image_url=? WHERE id=?',
            (request.form.get('name'), request.form.get('email'), request.form.get('phone'),
             request.form.get('specialty_id'), request.form.get('experience',0),
             request.form.get('qualification'), request.form.get('status'), request.form.get('bio'),
             new_photo, doctor_id)
        )
    else:
        conn.execute(
            'UPDATE doctors SET name=?,email=?,phone=?,specialty_id=?,experience=?,qualification=?,status=?,bio=? WHERE id=?',
            (request.form.get('name'), request.form.get('email'), request.form.get('phone'),
             request.form.get('specialty_id'), request.form.get('experience',0),
             request.form.get('qualification'), request.form.get('status'), request.form.get('bio'),
             doctor_id)
        )
    if new_pwd:
        conn.execute('UPDATE doctors SET password=? WHERE id=?', (hash_password(new_pwd), doctor_id))
    conn.commit(); conn.close()
    flash('Doctor updated successfully!', 'success')
    return redirect(url_for('admin_dashboard'))

# Admin: Delete Doctor
@app.route('/admin/doctors/delete/<int:doctor_id>', methods=['POST'])
@admin_required
def delete_doctor(doctor_id):
    conn = get_db()
    row  = conn.execute('SELECT image_url FROM doctors WHERE id=?', (doctor_id,)).fetchone()
    if row and row['image_url']:
        p = os.path.join(UPLOAD_FOLDER, row['image_url'])
        if os.path.exists(p): os.remove(p)
    name_row = conn.execute('SELECT name FROM doctors WHERE id=?', (doctor_id,)).fetchone()
    conn.execute('DELETE FROM doctors WHERE id=?', (doctor_id,))
    conn.execute('INSERT INTO admin_logs (admin_id, action) VALUES (?,?)',
                 (session['admin_id'], f"Deleted doctor: {name_row['name'] if name_row else 'Unknown'}"))
    conn.commit(); conn.close()
    flash('Doctor removed.', 'success')
    return redirect(url_for('admin_dashboard'))

# Admin: Update Appointment Status
@app.route('/admin/appointments/update/<int:appt_id>', methods=['POST'])
@admin_required
def update_appointment(appt_id):
    status = request.form.get('status')
    conn   = get_db()
    conn.execute('UPDATE appointments SET status=? WHERE id=?', (status, appt_id))
    conn.commit(); conn.close()
    flash(f'Appointment status updated to {status}.', 'success')
    return redirect(url_for('admin_dashboard') + '#appointments')

# ── Schedule Management (AJAX API) ──────
@app.route('/admin/doctors/<int:doctor_id>/schedule')
@admin_required
def get_schedule(doctor_id):
    conn      = get_db()
    doctor    = conn.execute('SELECT id, name FROM doctors WHERE id=?', (doctor_id,)).fetchone()
    schedules = conn.execute(
        'SELECT * FROM doctor_schedules WHERE doctor_id=? ORDER BY id', (doctor_id,)
    ).fetchall()
    conn.close()
    return jsonify({
        'doctor':    {'id': doctor['id'], 'name': doctor['name']},
        'schedules': [dict(s) for s in schedules]
    })

@app.route('/admin/doctors/<int:doctor_id>/schedule/add', methods=['POST'])
@admin_required
def add_schedule(doctor_id):
    data  = request.get_json()
    day   = data.get('day_of_week')
    start = data.get('start_time')
    end   = data.get('end_time')
    if not all([day, start, end]):
        return jsonify({'error': 'Missing fields'}), 400
    conn  = get_db()
    cursor = conn.execute(
        'INSERT INTO doctor_schedules (doctor_id, day_of_week, start_time, end_time) VALUES (?,?,?,?)',
        (doctor_id, day, start, end)
    )
    conn.commit()
    new_id = cursor.lastrowid
    conn.close()
    return jsonify({'id': new_id, 'doctor_id': doctor_id, 'day_of_week': day, 'start_time': start, 'end_time': end})

@app.route('/admin/schedule/delete/<int:schedule_id>', methods=['POST'])
@admin_required
def delete_schedule(schedule_id):
    conn = get_db()
    conn.execute('DELETE FROM doctor_schedules WHERE id=?', (schedule_id,))
    conn.commit(); conn.close()
    return jsonify({'ok': True})

# ── Available Slots API (for patient booking) ──
@app.route('/api/slots/<int:doctor_id>/<date_str>')
def available_slots(doctor_id, date_str):
    try:
        date_obj = datetime.strptime(date_str, '%Y-%m-%d')
    except ValueError:
        return jsonify([])
    day_name = date_obj.strftime('%A')
    conn     = get_db()
    schedules = conn.execute(
        'SELECT * FROM doctor_schedules WHERE doctor_id=? AND day_of_week=?',
        (doctor_id, day_name)
    ).fetchall()
    booked_rows = conn.execute(
        "SELECT appt_time FROM appointments WHERE doctor_id=? AND appt_date=? AND status!='Cancelled'",
        (doctor_id, date_str)
    ).fetchall()
    conn.close()
    booked_times = {r['appt_time'] for r in booked_rows}
    slots = []
    for sch in schedules:
        cur = datetime.strptime(sch['start_time'], '%H:%M')
        end = datetime.strptime(sch['end_time'],   '%H:%M')
        while cur < end:
            t = cur.strftime('%H:%M')
            slots.append({'time': t, 'available': t not in booked_times})
            cur += timedelta(minutes=30)
    return jsonify(slots)

# ─────────────────────────────────────────
# Logout
# ─────────────────────────────────────────
@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(debug=True, port=5000)
