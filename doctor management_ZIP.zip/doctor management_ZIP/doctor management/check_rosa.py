import sqlite3

conn = sqlite3.connect('medimanage.db')
cursor = conn.cursor()

cursor.execute("SELECT name, phone FROM patients WHERE name LIKE '%rosa%' OR name LIKE '%Rosa%'")
rows = cursor.fetchall()
print("Patient found:", rows)

conn.close()
