# 🏥 MediManage - Setup Guide

Follow these steps to set up and run MediManage on a new laptop.

## 1. Prerequisites
Ensure you have **Python 3.8 or higher** installed on your system.
- Download it from [python.org](https://www.python.org/downloads/) if you haven't already.
- Make sure to check the box **"Add Python to PATH"** during installation.

## 2. Copy the Project
Copy the entire `doctor management` folder to your new laptop's drive.

## 3. Install Dependencies
Open your terminal (PowerShell or Command Prompt), navigate to the project folder, and run:
```powershell
pip install -r requirements.txt
```

## 4. Initialize the Database
If you've copied the `medimanage.db` file, you're all set. If you're starting with a fresh database:
1. Run the initial database setup:
   ```powershell
   python setup_db.py
   ```
2. Run the migration to add advanced features:
   ```powershell
   python migrate_v2.py
   ```

## 5. Launch the Application
Start the server by running:
```powershell
python app.py
```
Open your browser and visit: `http://127.0.0.1:5000`

### 🔑 Default Admin Credentials
- **Email**: `admin@medimanage.com`
- **Password**: `admin123`

---
*Note: Make sure the `static/uploads` directory exists if you want to handle file uploads correctly.*
