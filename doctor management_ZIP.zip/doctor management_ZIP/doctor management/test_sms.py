import requests

API_KEY = 'UMyQKJ7wRdaAHEvFl5Xg3pkjZr0WtbziPumhTs41YG8NIneSqx18PFhaqsH9Rj6IONgBJKfDAk2mQWLd'

url = "https://www.fast2sms.com/dev/bulkV2"
payload = {
    "route": "v3",
    "sender_id": "TXTIND",
    "message": "Test SMS from MediManage app",
    "flash": 0,
    "numbers": "6374096426"
}
headers = {
    "authorization": API_KEY,
    "Content-Type": "application/x-www-form-urlencoded"
}

response = requests.post(url, data=payload, headers=headers)
print("Status Code:", response.status_code)
print("Response:", response.text)
