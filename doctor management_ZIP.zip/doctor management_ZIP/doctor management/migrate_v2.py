import sqlite3
import os

DB_PATH = os.path.join(os.path.dirname(__file__), "medimanage.db")

def migrate_v2():
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()

    print("[1/5] Updating Doctors table...")
    try:
        cursor.execute("ALTER TABLE doctors ADD COLUMN consultation_fee INTEGER DEFAULT 500")
    except sqlite3.OperationalError: pass # Already exists

    print("[2/5] Updating Appointments table...")
    try:
        cursor.execute("ALTER TABLE appointments ADD COLUMN prescription_notes TEXT")
        cursor.execute("ALTER TABLE appointments ADD COLUMN fee INTEGER DEFAULT 500")
        cursor.execute("ALTER TABLE appointments ADD COLUMN payment_status TEXT DEFAULT 'Unpaid' CHECK(payment_status IN ('Unpaid', 'Paid'))")
    except sqlite3.OperationalError: pass

    print("[3/5] Creating Patient Records table...")
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS patient_records (
            id           INTEGER PRIMARY KEY AUTOINCREMENT,
            patient_id   INTEGER NOT NULL REFERENCES patients(id) ON DELETE CASCADE,
            file_name    TEXT    NOT NULL,
            label        TEXT,
            upload_date  TEXT    DEFAULT (datetime('now'))
        )
    """)

    print("[4/5] Creating Admin Logs table...")
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS admin_logs (
            id         INTEGER PRIMARY KEY AUTOINCREMENT,
            admin_id   INTEGER REFERENCES admins(id),
            action     TEXT    NOT NULL,
            timestamp  TEXT    DEFAULT (datetime('now'))
        )
    """)

    print("[5/5] Creating Password Reset Tokens table...")
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS reset_tokens (
            id         INTEGER PRIMARY KEY AUTOINCREMENT,
            email      TEXT    NOT NULL,
            token      TEXT    NOT NULL UNIQUE,
            expiry     TEXT    NOT NULL,
            user_type  TEXT    CHECK(user_type IN ('patient', 'doctor', 'admin'))
        )
    """)

    conn.commit()
    conn.close()
    print("\n[OK] Migration V2 completed successfully!")

if __name__ == "__main__":
    migrate_v2()
