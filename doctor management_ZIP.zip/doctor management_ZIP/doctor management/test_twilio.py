import os
from twilio.rest import Client

TWILIO_ACCOUNT_SID = 'AC6902d2f227b8877ccd6db562d5168431'
TWILIO_AUTH_TOKEN = '43ef15fffa4e7cd2c664502b7ad713ef'
TWILIO_PHONE_NUMBER = '+16205571922'

# We'll use Rosa's number for the test
to_phone = '+916374096426'

try:
    client = Client(TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN)
    message = client.messages.create(
        body="Test SMS from MediManage app (Twilio)",
        from_=TWILIO_PHONE_NUMBER,
        to=to_phone
    )
    print(f"Success! Message sent with SID: {message.sid}")
except Exception as e:
    print(f"Error sending SMS: {e}")
