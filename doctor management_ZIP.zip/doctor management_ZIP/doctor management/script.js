// Sample Initial Data
let doctors = [
    {
        id: 1,
        name: "Dr. Sarah Jenkins",
        specialty: "Cardiology",
        experience: 12,
        email: "sarah.jenkins@hospital.com",
        status: "Available",
        image: "https://i.pravatar.cc/150?img=5"
    },
    {
        id: 2,
        name: "Dr. Michael Chen",
        specialty: "Neurology",
        experience: 8,
        email: "michael.chen@hospital.com",
        status: "In Surgery",
        image: "https://i.pravatar.cc/150?img=11"
    },
    {
        id: 3,
        name: "Dr. Emily Rodriguez",
        specialty: "Pediatrics",
        experience: 5,
        email: "emily.rodriguez@hospital.com",
        status: "Available",
        image: "https://i.pravatar.cc/150?img=9"
    },
    {
        id: 4,
        name: "Dr. James Wilson",
        specialty: "Orthopedics",
        experience: 15,
        email: "james.wilson@hospital.com",
        status: "On Leave",
        image: "https://i.pravatar.cc/150?img=8"
    },
    {
        id: 5,
        name: "Dr. Olivia Martinez",
        specialty: "General Surgery",
        experience: 10,
        email: "olivia.martinez@hospital.com",
        status: "Available",
        image: "https://i.pravatar.cc/150?img=20"
    },
    {
        id: 6,
        name: "Dr. David Kim",
        specialty: "Cardiology",
        experience: 7,
        email: "david.kim@hospital.com",
        status: "Available",
        image: "https://i.pravatar.cc/150?img=15"
    }
];

// DOM Elements
const doctorGrid = document.getElementById('doctorGrid');
const searchInput = document.getElementById('searchInput');
const specialtyFilter = document.getElementById('specialtyFilter');
const addDoctorBtn = document.getElementById('addDoctorBtn');
const addDoctorModal = document.getElementById('addDoctorModal');
const closeModalBtn = document.getElementById('closeModalBtn');
const cancelBtn = document.getElementById('cancelBtn');
const addDoctorForm = document.getElementById('addDoctorForm');

// Helper function to get status class
const getStatusClass = (status) => {
    switch (status) {
        case 'Available': return 'status-available';
        case 'On Leave': return 'status-on-leave';
        case 'In Surgery': return 'status-in-surgery';
        default: return '';
    }
};

// Render Doctors
const renderDoctors = (docs) => {
    doctorGrid.innerHTML = '';
    
    if (docs.length === 0) {
        doctorGrid.innerHTML = '<div style="grid-column: 1/-1; text-align: center; padding: 3rem; color: var(--text-secondary);">No doctors found.</div>';
        return;
    }

    docs.forEach((doc, index) => {
        const card = document.createElement('div');
        card.className = 'doctor-card';
        card.style.animationDelay = `${index * 0.1}s`;
        
        card.innerHTML = `
            <div class="card-header">
                <div class="doc-info">
                    <img src="${doc.image}" alt="${doc.name}" class="doc-avatar">
                    <div>
                        <h3 class="doc-name">${doc.name}</h3>
                        <div class="doc-specialty">${doc.specialty}</div>
                        <div class="doc-exp">${doc.experience} Years Experience</div>
                    </div>
                </div>
            </div>
            <div class="card-body">
                <div class="contact-info">
                    <i class="fa-regular fa-envelope"></i>
                    <span>${doc.email}</span>
                </div>
                <div class="contact-info" style="margin-bottom: 1rem;">
                    <i class="fa-solid fa-circle-check" style="color: ${doc.status === 'Available' ? 'var(--success)' : doc.status === 'On Leave' ? 'var(--danger)' : 'var(--warning)'};"></i>
                    <span class="status-badge ${getStatusClass(doc.status)}">${doc.status}</span>
                </div>
                <div class="card-actions">
                    <button class="btn btn-secondary">Profile</button>
                    <button class="btn btn-primary" ${doc.status !== 'Available' ? 'disabled style="opacity:0.6; cursor:not-allowed;"' : ''}>Book Appt</button>
                </div>
            </div>
        `;
        doctorGrid.appendChild(card);
    });
};

// Filter & Search Logic
const filterDoctors = () => {
    const searchTerm = searchInput.value.toLowerCase();
    const specialty = specialtyFilter.value;

    const filteredDocs = doctors.filter(doc => {
        const matchesSearch = doc.name.toLowerCase().includes(searchTerm) || 
                              doc.specialty.toLowerCase().includes(searchTerm);
        const matchesSpecialty = specialty === 'all' || doc.specialty === specialty;
        
        return matchesSearch && matchesSpecialty;
    });

    renderDoctors(filteredDocs);
};

// Event Listeners for Search & Filter
searchInput.addEventListener('input', filterDoctors);
specialtyFilter.addEventListener('change', filterDoctors);

// Modal Logic
const openModal = () => {
    addDoctorModal.classList.add('active');
    document.body.style.overflow = 'hidden';
};

const closeModal = () => {
    addDoctorModal.classList.remove('active');
    document.body.style.overflow = 'auto';
    addDoctorForm.reset();
};

addDoctorBtn.addEventListener('click', openModal);
closeModalBtn.addEventListener('click', closeModal);
cancelBtn.addEventListener('click', closeModal);

// Close modal on clicking outside
addDoctorModal.addEventListener('click', (e) => {
    if (e.target === addDoctorModal) {
        closeModal();
    }
});

// Form Submission
addDoctorForm.addEventListener('submit', (e) => {
    e.preventDefault();
    
    const name = document.getElementById('docName').value;
    const specialty = document.getElementById('docSpecialty').value;
    const experience = parseInt(document.getElementById('docExperience').value);
    const email = document.getElementById('docEmail').value;
    const status = document.querySelector('input[name="docStatus"]:checked').value;
    
    // Generate random avatar
    const randomImgId = Math.floor(Math.random() * 70);
    
    const newDoctor = {
        id: doctors.length + 1,
        name: name,
        specialty: specialty,
        experience: experience,
        email: email,
        status: status,
        image: `https://i.pravatar.cc/150?img=${randomImgId}`
    };
    
    doctors.unshift(newDoctor); // Add to beginning
    filterDoctors(); // Re-render with current filters
    closeModal();
    
    // Optional: Show a subtle toast notification here
});

// Initial Render
renderDoctors(doctors);
